# 🍷 Exploratory Data Analysis: Wine Recognition Dataset

A complete, end-to-end Exploratory Data Analysis (EDA) project examining the chemical composition of wines from three Italian cultivars, identifying the strongest correlations and key features that distinguish wine classes.

## 📌 Project Overview

| | |
|---|---|
| **Objective** | Uncover patterns, distributions, and relationships in wine chemistry data |
| **Dataset** | [UCI Wine Recognition Dataset](https://archive.ics.uci.edu/ml/datasets/Wine) (178 samples, 13 features, 3 classes) |
| **Tools** | Python, Pandas, NumPy, Matplotlib, Seaborn, Scikit-learn |
| **Deliverables** | Jupyter Notebook, standalone analysis script, charts, written report |

## 🎯 Key Features of This Analysis

- **Statistical summaries** — descriptive statistics, data quality checks (missing values, duplicates, class balance)
- **Univariate analysis** — distribution histograms and boxplots for all 13 chemical features
- **Bivariate / multivariate analysis** — pairplots, scatterplots, and violin plots split by wine class
- **Correlation analysis** — full correlation heatmap and ranked list of strongest feature relationships
- **Structured insights report** — written findings tying statistics back to real-world interpretation

## 📂 Repository Structure

```
wine-eda-project/
├── data/
│   └── wine_dataset.csv              # Raw dataset (UCI Wine Recognition Dataset)
├── notebooks/
│   └── EDA_Wine_Dataset.ipynb        # Full executed analysis notebook (run this first)
├── src/
│   └── eda_analysis.py               # Standalone script — regenerates all charts/stats
├── images/
│   ├── 01_class_distribution.png
│   ├── 02_feature_histograms.png
│   ├── 03_boxplots_by_class.png
│   ├── 04_correlation_heatmap.png
│   ├── 05_pairplot_key_features.png
│   ├── 06_key_relationships.png
│   └── 07_violin_key_features.png
├── reports/
│   ├── EDA_Report.md                 # Structured written report of findings
│   ├── summary_statistics.csv        # Exported descriptive statistics
│   └── top_correlations.txt          # Exported ranked correlation pairs
├── requirements.txt
├── LICENSE
└── README.md
```

## 🚀 How to Run

1. **Clone the repo**
   ```bash
   git clone https://github.com/<your-username>/wine-eda-project.git
   cd wine-eda-project
   ```

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Run the analysis**

   Option A — Jupyter Notebook (recommended, shows step-by-step narrative):
   ```bash
   jupyter notebook notebooks/EDA_Wine_Dataset.ipynb
   ```

   Option B — Standalone script (regenerates all charts + stats into `/images` and `/reports`):
   ```bash
   python src/eda_analysis.py
   ```

## 📊 Dataset Description

The dataset contains the results of a chemical analysis of 178 wines grown in the same region of Italy, derived from **three different cultivars**. Thirteen chemical measurements were recorded for each sample:

`alcohol`, `malic_acid`, `ash`, `alcalinity_of_ash`, `magnesium`, `total_phenols`, `flavanoids`, `nonflavanoid_phenols`, `proanthocyanins`, `color_intensity`, `hue`, `od280/od315_of_diluted_wines`, `proline`

The data is clean: **zero missing values** and **zero duplicate rows**, with a reasonably balanced class split (59 / 71 / 48 samples).

## 🔍 Key Insights

1. **Strongest correlation:** `total_phenols` and `flavanoids` (r ≈ 0.86) — chemically expected, since flavanoids are a sub-class of phenolic compounds.
2. **Most class-discriminative features:** `flavanoids`, `color_intensity`, `proline`, and `od280/od315_of_diluted_wines` show the clearest separation across the three cultivars in boxplots and pairplots.
3. **Phenolic compounds cluster together:** `total_phenols`, `flavanoids`, `proanthocyanins`, and `od280/od315_of_diluted_wines` are all moderately-to-strongly inter-correlated (r = 0.6–0.86), indicating redundant chemical information.
4. **Scale disparity:** Features range from `hue` (~0.4–1.7) to `proline` (~278–1680), meaning any distance-based modeling downstream would require standardization.
5. **Practical implication:** A classifier using just 4–5 of the most discriminative features could likely separate the three cultivars with high accuracy — a natural next step beyond EDA.

See [`reports/EDA_Report.md`](reports/EDA_Report.md) for the full structured write-up.

## 🖼️ Sample Visualization

![Correlation Heatmap](images/04_correlation_heatmap.png)

## 🧠 Skills Demonstrated

- Data cleaning & validation (missing values, duplicates, dtype checks)
- Descriptive statistics & distribution analysis
- Correlation analysis and multivariate visualization
- Translating statistical findings into clear, structured insights
- Reproducible analysis (script + notebook produce identical results)

## 📄 License

This project is licensed under the MIT License — see [LICENSE](LICENSE) for details.

## 🙏 Acknowledgments

Dataset originally created by Forina, M. et al., PARVUS — sourced via the [UCI Machine Learning Repository](https://archive.ics.uci.edu/ml/datasets/Wine) and distributed through `scikit-learn.datasets.load_wine`.
