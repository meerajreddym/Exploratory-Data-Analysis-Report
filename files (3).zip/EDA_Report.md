# Exploratory Data Analysis Report
## Wine Recognition Dataset

**Author:** [Your Name]
**Date:** June 2026

---

## 1. Introduction

This report presents an exploratory data analysis (EDA) of the UCI Wine Recognition Dataset, which contains chemical measurements of 178 wine samples derived from three different cultivars grown in the same region of Italy. The objective is to understand the structure of the data, identify patterns and relationships among the 13 chemical features, and determine which features most strongly distinguish the three cultivars.

## 2. Dataset Description

| Property | Value |
|---|---|
| Number of samples | 178 |
| Number of features | 13 (all numeric, continuous) |
| Target classes | 3 cultivars (class_0: 59, class_1: 71, class_2: 48) |
| Missing values | 0 |
| Duplicate rows | 0 |

Features measured: alcohol, malic acid, ash, alkalinity of ash, magnesium, total phenols, flavanoids, nonflavanoid phenols, proanthocyanins, color intensity, hue, OD280/OD315 of diluted wines, and proline.

## 3. Methodology

The analysis followed a standard EDA workflow:

1. **Data quality validation** — checked for missing values, duplicate records, and correct data types.
2. **Descriptive statistics** — computed mean, median, standard deviation, and quartile ranges for all features.
3. **Univariate analysis** — visualized individual feature distributions (histograms) and checked for outliers (boxplots), both overall and split by class.
4. **Bivariate / multivariate analysis** — examined relationships between feature pairs using scatterplots, pairplots, and violin plots, segmented by cultivar.
5. **Correlation analysis** — computed the full Pearson correlation matrix and ranked the strongest feature pairs.

All code is available in `src/eda_analysis.py` and is fully reproducible; results match those shown in `notebooks/EDA_Wine_Dataset.ipynb`.

## 4. Statistical Summary

Full descriptive statistics are exported to `reports/summary_statistics.csv`. Notable observations:

- Features operate on very different numeric scales (e.g., `proline` spans roughly 278–1680, while `hue` spans roughly 0.4–1.7), which would require standardization before any distance-based modeling.
- `proline` and `magnesium` show the largest absolute variability across samples.
- Most features are approximately unimodal, though `malic_acid`, `color_intensity`, and `proanthocyanins` are right-skewed with a tail of higher values.

## 5. Univariate Findings

- **Class distribution** is reasonably balanced across the three cultivars (33%, 40%, 27% of samples respectively), so no resampling was needed.
- **Outlier check:** boxplots split by class revealed mild outliers in `magnesium` and `proanthocyanins`, but none extreme enough to suggest data entry errors.
- **Class-separating features:** `flavanoids`, `proline`, `color_intensity`, and `od280/od315_of_diluted_wines` show visibly distinct medians and interquartile ranges across the three classes, marking them as strong candidate predictors of cultivar.

## 6. Bivariate & Multivariate Findings

- **Flavanoids vs. Total Phenols:** a strong, near-linear positive relationship. The three cultivars form visibly separate diagonal bands on this plot, suggesting these two features together are highly discriminative of wine class.
- **Alcohol vs. Proline:** class_0 wines cluster at high values of both alcohol and proline, while class_1 wines cluster at lower values on both axes — a second strong discriminating pair.
- **Pairplot of key features** (flavanoids, total_phenols, color_intensity, proline, alcohol) confirms that combining just a handful of features yields visibly separable clusters by cultivar, without need for the full 13-dimensional feature space.

## 7. Correlation Analysis

The top correlated feature pairs (by absolute Pearson correlation) are:

| Feature 1 | Feature 2 | Correlation |
|---|---|---|
| total_phenols | flavanoids | 0.86 |
| flavanoids | od280/od315_of_diluted_wines | 0.79 |
| total_phenols | od280/od315_of_diluted_wines | 0.70 |
| flavanoids | proanthocyanins | 0.65 |
| alcohol | proline | 0.64 |
| total_phenols | proanthocyanins | 0.61 |
| hue | od280/od315_of_diluted_wines | 0.57 |
| malic_acid | hue | -0.56 |

**Interpretation:** The four phenolic-compound-related features (`total_phenols`, `flavanoids`, `proanthocyanins`, `od280/od315_of_diluted_wines`) are all strongly inter-correlated, which is chemically expected since they measure related compounds via similar laboratory methods. This redundancy means a smaller set of these features (or a derived principal component) could capture most of the same signal. `alcohol` and `proline` form a second, independent correlated pair worth retaining as it carries distinct information.

## 8. Key Influencing Factors

Based on the combined evidence from boxplots, pairplots, and correlation analysis, the chemical properties that most strongly differentiate the three wine cultivars are:

1. **Flavanoids**
2. **Color intensity**
3. **Proline**
4. **OD280/OD315 of diluted wines**
5. **Alcohol**

These five features, despite representing less than half of the original 13, appear sufficient to visually separate the three classes in scatterplots — suggesting strong potential for dimensionality reduction in any downstream classification task.

## 9. Conclusion

This EDA confirms that the Wine Recognition Dataset is clean, well-structured, and contains clear chemical signatures that distinguish the three cultivars. Phenolic compounds form a tightly correlated cluster of features, while alcohol and proline provide an independent axis of separation. These findings provide a strong foundation for a follow-up classification model (e.g., logistic regression, random forest, or k-NN with standardized features) to predict wine cultivar from chemical measurements alone.

## 10. Next Steps

- Apply feature scaling (StandardScaler) and train a baseline classifier (e.g., Random Forest or SVM) using the top 5 discriminative features.
- Apply PCA to confirm whether 2–3 principal components capture the majority of variance, given the high inter-feature correlation observed.
- Validate generalizability with cross-validation, given the modest sample size (178 rows).
